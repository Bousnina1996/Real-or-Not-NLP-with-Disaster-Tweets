from django.apps import AppConfig


class NlpMachinelearningConfig(AppConfig):
    name = 'nlp_MachineLearning'
